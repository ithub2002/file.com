import pandas as pd
##data = [['Ossama',25],['Ali',43],['Ziad',32]]
##DF1 = pd.DataFrame(data,columns=['Name','Age'])
##print (DF1)
##data = [['Ossama',25],['Ali',43],['Ziad',32]]
##DF1 = pd.DataFrame(data,columns=['Name','Age'],dtype=float)
##print (DF1)

##data = [{'Test1': 10, 'Test2': 20},{'Test1': 30,'Test2': 20, 'Project': 20}]
##df1 = pd.DataFrame(data, index=['First', 'Second'],columns=['Test2', 'Project' , 'Test1'])
##df2 = pd.DataFrame(data, index=['First', 'Second'],columns=['Project', 'Test_1','Test2 '])
##print (df1)
##print ("\n")
##print (df2)

data = {'Test1' : pd.Series([70, 55, 89],index=['Ahmed', 'Omar', 'Ali']),
'Test2' :pd.Series([56, 82, 77, 65],index=['Ahmed', 'Omar', 'Ali', 'Salwa'])}
df1 = pd.DataFrame(data)
print (df1)

df1['Project'] = pd.Series([90,83,67, 87],index=['Ali','Omar','Salwa', 'Ahmed'])
print ("\n")
df1['Average'] = round((df1['Test1']+df1['Test2']+df1['Project'])/3, 2)
print (df1)
df2 = df1
df2.pop('Project')
print (df2) 


##print ("\nslice rows")
##print (df1[2:4])

data = {'Test1' : pd.Series([70, 55, 89],index=['Ahmed', 'Omar', 'Ali']),
'Test2' :pd.Series([56, 82, 77, 65],index=['Ahmed', 'Omar', 'Ali', 'Salwa'])}
df2 = pd.DataFrame([[80, 70, 90, 80]], columns= ['Test1','Test2','Project','Average'],index=['Khalid'])
data.append(df2)
